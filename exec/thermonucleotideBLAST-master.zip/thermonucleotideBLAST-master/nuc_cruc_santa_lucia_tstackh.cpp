// ******************************************************************************
// This is an empty file that would otherwise contain DNA hybridization parameters
// extracted from the UNAfold program.
// However, since unafold is not open source software, we can not
// distribute this code outside of LANL!
// ******************************************************************************

